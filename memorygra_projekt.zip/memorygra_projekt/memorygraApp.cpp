/***************************************************************
 * Name:      memorygraApp.cpp
 * Purpose:   Code for Application Class
 * Author:     ()
 * Created:   2025-06-01
 * Copyright:  ()
 * License:
 **************************************************************/

#include "memorygraApp.h"

//(*AppHeaders
#include "memorygraMain.h"
#include <wx/image.h>
//*)

IMPLEMENT_APP(memorygraApp);

bool memorygraApp::OnInit()
{
    //(*AppInitialize
    bool wxsOK = true;
    wxInitAllImageHandlers();
    if ( wxsOK )
    {
    	memorygraFrame* Frame = new memorygraFrame(0);
    	Frame->Show();
    	SetTopWindow(Frame);
    }
    //*)
    return wxsOK;

}
