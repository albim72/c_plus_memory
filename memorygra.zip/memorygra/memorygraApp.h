/***************************************************************
 * Name:      memorygraApp.h
 * Purpose:   Defines Application Class
 * Author:     ()
 * Created:   2025-06-01
 * Copyright:  ()
 * License:
 **************************************************************/

#ifndef MEMORYGRAAPP_H
#define MEMORYGRAAPP_H

#include <wx/app.h>

class memorygraApp : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // MEMORYGRAAPP_H
