/***************************************************************
 * Name:      memorygraMain.cpp
 * Purpose:   Code for Application Frame
 * Author:     ()
 * Created:   2025-06-01
 * Copyright:  ()
 * License:
 **************************************************************/

#include "memorygraMain.h"
#include <wx/msgdlg.h>
#include <wx/sizer.h>
#include <wx/button.h>
#include <vector>
#include <algorithm>
#include <random>
#include <ctime>
#include <wx/timer.h>
//(*InternalHeaders(memorygraFrame)
#include <wx/intl.h>
#include <wx/string.h>
//*)

//helper functions
enum wxbuildinfoformat {
    short_f, long_f };

wxString wxbuildinfo(wxbuildinfoformat format)
{
    wxString wxbuild(wxVERSION_STRING);

    if (format == long_f )
    {
#if defined(__WXMSW__)
        wxbuild << _T("-Windows");
#elif defined(__UNIX__)
        wxbuild << _T("-Linux");
#endif

#if wxUSE_UNICODE
        wxbuild << _T("-Unicode build");
#else
        wxbuild << _T("-ANSI build");
#endif // wxUSE_UNICODE
    }

    return wxbuild;
}

//(*IdInit(memorygraFrame)
const long memorygraFrame::idMenuQuit = wxNewId();
const long memorygraFrame::idMenuAbout = wxNewId();
const long memorygraFrame::ID_STATUSBAR1 = wxNewId();
//*)

BEGIN_EVENT_TABLE(memorygraFrame,wxFrame)
    //(*EventTable(memorygraFrame)
    //*)
END_EVENT_TABLE()

const int GRID_SIZE = 4;

memorygraFrame::memorygraFrame(wxWindow* parent,wxWindowID id)
    : wxFrame(parent, id, "Memory Game", wxDefaultPosition, wxSize(400, 400))
{
    StatusBar1 = this->CreateStatusBar();
{
    wxPanel* panel = new wxPanel(this);

    wxGridSizer* grid = new wxGridSizer(GRID_SIZE, GRID_SIZE, 5, 5);
    panel->SetSizer(grid);

    std::vector<std::string> cardValues;
    std::mt19937 rng(std::time(nullptr));
    std::uniform_int_distribution<> dist(0, 9);

    for (int i = 0; i < (GRID_SIZE * GRID_SIZE) / 2; ++i) {
    std::string seq;
    for (int j = 0; j < 5; ++j) {
        seq += std::to_string(dist(rng));
    }
    cardValues.push_back(seq);
    cardValues.push_back(seq); // dodaj parę
}

std::shuffle(cardValues.begin(), cardValues.end(), rng);

    std::shuffle(cardValues.begin(), cardValues.end(), std::mt19937(std::time(nullptr)));

    for (int i = 0; i < GRID_SIZE * GRID_SIZE; ++i) {
        wxButton* btn = new wxButton(panel, 1000 + i, "?", wxDefaultPosition, wxSize(60, 60));
        btn->SetClientData(new std::string(cardValues[i]));
        btn->Bind(wxEVT_BUTTON, &memorygraFrame::OnCardClicked, this);
        grid->Add(btn, 0, wxEXPAND);
        cards.push_back(btn);
    }
}
flipBackTimer = new wxTimer(this);
Bind(wxEVT_TIMER, &memorygraFrame::OnFlipBackTimer, this);

secondsElapsed = 0;
gameTimer = new wxTimer(this, wxID_ANY);
Bind(wxEVT_TIMER, &memorygraFrame::OnGameTimer, this, gameTimer->GetId());

// Uruchom timer na początku gry (np. zaraz po ustawieniu kart)
gameTimer->Start(1000); // odliczaj co 1000 ms (1 sekunda)

}
void memorygraFrame::OnCardClicked(wxCommandEvent& event)
{
    if (flipBackTimer->IsRunning()) return;

    wxButton* btn = dynamic_cast<wxButton*>(event.GetEventObject());
    if (!btn || btn == firstCard || btn == secondCard || !btn->IsEnabled())
        return;

    std::string* value = static_cast<std::string*>(btn->GetClientData());
    btn->SetLabel(*value);

    if (!firstCard) {
        firstCard = btn;
    } else {
        secondCard = btn;

        std::string* val1 = static_cast<std::string*>(firstCard->GetClientData());
        std::string* val2 = static_cast<std::string*>(secondCard->GetClientData());

        moveCount++;
        StatusBar1->SetStatusText("Ruchy: " + std::to_string(moveCount));

        if (*val1 != *val2) {
            // Nie pasują - zakryj karty po czasie
            flipBackTimer->StartOnce(700);
            wxYield();
        } else {
            // Pasują - wyłącz przyciski kart
            firstCard->Disable();
            secondCard->Disable();

            firstCard = nullptr;
            secondCard = nullptr;

            if (AllCardsMatched()) {
                gameTimer->Stop();
                wxString msg = wxString::Format(wxT("Gratulacje! Ukończyłeś grę w %d ruchach w czasie %d sekund."), moveCount, secondsElapsed);
                wxMessageBox(msg, wxT("Koniec gry"), wxOK | wxICON_INFORMATION);
        }
        }
    }
}
void memorygraFrame::OnFlipBackTimer(wxTimerEvent& event)
{
    if (firstCard && secondCard) {
        firstCard->SetLabel("?");
        secondCard->SetLabel("?");
        // Przyciski pozostają włączone, bo para była niepasująca
    }
    firstCard = nullptr;
    secondCard = nullptr;
}
bool memorygraFrame::AllCardsMatched()
{
    for (auto btn : cards) {
        if (btn->IsEnabled()) {
            // Znaleziono jeszcze kartę, która jest zakryta
            return false;
        }
    }
    return true; // Gra ukonczona
}
void memorygraFrame::OnGameTimer(wxTimerEvent& event)
{
    secondsElapsed++;
    // Aktualizuj pasek statusu z czasem i ruchem
    wxString status = wxString::Format("Ruchy: %d    Czas: %d s", moveCount, secondsElapsed);
    StatusBar1->SetStatusText(status);
}

memorygraFrame::~memorygraFrame()
{
    //(*Destroy(memorygraFrame)
    //*)
}

void memorygraFrame::OnQuit(wxCommandEvent& event)
{
    Close();
}

void memorygraFrame::OnAbout(wxCommandEvent& event)
{
    wxString msg = wxbuildinfo(long_f);
    wxMessageBox(msg, _("Welcome to..."));
}
