UWAGA: Sprawozdanie nie zawiera grafik. Aby wygenerować kompletny PDF, należy dodać odpowiednie pliki graficzne tam, gdzie są użyte komendy \includegraphics w LaTeX.
