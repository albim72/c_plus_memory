/***************************************************************
 * Name:      memorygraMain.h
 * Purpose:   Defines Application Frame
 * Author:     ()
 * Created:   2025-06-01
 * Copyright:  ()
 * License:
 **************************************************************/

#ifndef MEMORYGRAMAIN_H
#define MEMORYGRAMAIN_H
#include <wx/timer.h>
#include <wx/sizer.h>
#include <wx/panel.h>

//(*Headers(memorygraFrame)
#include <wx/frame.h>
#include <wx/menu.h>
#include <wx/statusbr.h>
//*)

class memorygraFrame: public wxFrame
{
    public:

        memorygraFrame(wxWindow* parent,wxWindowID id = -1);
        virtual ~memorygraFrame();
        void OnFlipBackTimer(wxTimerEvent& event);
        void OnCardClicked(wxCommandEvent& event);


    private:
        wxButton* firstCard = nullptr;
        wxButton* secondCard = nullptr;
        wxTimer* flipBackTimer = nullptr;
        int moveCount = 0;
        bool AllCardsMatched();
        std::vector<wxButton*> cards;
        wxTimer* gameTimer;    // timer do odmierzania czasu gry
        int secondsElapsed;    // licznik sekund od startu gry
        void OnGameTimer(wxTimerEvent& event);
        void OnNewGame(wxCommandEvent& event);
        wxGridSizer* grid;
        wxPanel* panel;

        //(*Handlers(memorygraFrame)
        void OnQuit(wxCommandEvent& event);
        void OnAbout(wxCommandEvent& event);
        //*)

        //(*Identifiers(memorygraFrame)
        static const long idMenuQuit;
        static const long idMenuAbout;
        static const long ID_STATUSBAR1;
        //*)

        //(*Declarations(memorygraFrame)
        wxStatusBar* StatusBar1;
        //*)

        DECLARE_EVENT_TABLE()
};

#endif // MEMORYGRAMAIN_H
